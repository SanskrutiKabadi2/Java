package com.example.sqlite_flutter_crud

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
